This directory includes scripts to build the docker container image used for
building flutter/flutter in our CI system (currently [Cirrus](cirrus-ci.org)).

To run the scripts, you have to set up `docker` and `gcloud`. Please
refer to the [internal flutter team doc](go/flutter-team) for how to set up in a
Google internal environment.
