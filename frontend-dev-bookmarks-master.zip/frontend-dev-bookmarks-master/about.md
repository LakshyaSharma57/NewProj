# About this list

If I have a specific development task the workflow for me looks like this:

1. Search through Google, GitHub, Unheap, npm, bower, jster and so on.
2. Compile a list of useful packages and tutorials for every one of them.
3. Select the best package for the task.

So I created this list to not have to go through step #1 and #2 every time.
